
from django.urls import path
from hospital.views import About, Home ,Contact, Login, Logout_admin, Index, View_Doctor, Delete_doctor, Add_Doctor, View_patient, delete_patient,Add_Patient, view_Appointment,Add_Appointment,delete_Appointment

urlpatterns = [
    path('', Home, name='home'),
    path('about/', About, name='about'),
    path('Contact/', Contact, name='contact'),
    path('login/', Login, name='login'),
    path('logout/', Logout_admin, name='logout'),
    path('index/', Index, name='dashboard'),
    path('view_doctor/', View_Doctor, name='view_doctor'), 
    path('view_patient/',View_patient, name='view_patient'), 
    path('view_Appointment/',view_Appointment, name='view_appointment'), 
    path('add_doctor/', Add_Doctor, name='add_doctor'), 
    path('add_patient/', Add_Patient, name='add_patient'), 
    path('add_appointment/', Add_Appointment, name='add_appointment'), 
    path('delete_doctor(?p<int:pid>)',Delete_doctor, name='delete_doctor'), 
    path('delete_patient(?p<int:pid>)',delete_patient, name='delete_patient'), 
    path('delete_Appointment(?p<int:pid>)', delete_Appointment, name='delete_appointment'), 
    
    
   
   
   ]
 