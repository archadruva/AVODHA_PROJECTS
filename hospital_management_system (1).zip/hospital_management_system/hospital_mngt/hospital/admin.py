from django.contrib import admin
from.models import patient,Doctor,Appointment
# Register your models here.
admin.site.register(Doctor)
admin.site.register(patient)
admin.site.register(Appointment)

class Doctor(admin.ModelAdmin):
    list_display=['name', 'specialization', 'experience']

