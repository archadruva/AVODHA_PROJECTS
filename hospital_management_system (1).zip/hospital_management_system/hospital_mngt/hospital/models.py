from django.db import models

# Create your models here.
class Doctor(models.Model):
    Name= models.CharField(max_length=50 )
    mobile = models.IntegerField()
    special = models.CharField(max_length=50)

    def __str__(self):
        return  f"{self.Name}-{self.mobile}-{self.special}"
    




class patient(models.Model):
    name = models.CharField(max_length=50)
    gender = models.CharField(max_length=10)
    mobile = models.IntegerField(null=True)
    address = models.TextField()

    def __str__(self):
        return f"{self.name}-{self.gender}-{self.mobile}-{self.address}"




class Appointment(models.Model):
    Doctor = models.ForeignKey(Doctor,on_delete=models.CASCADE)
    Patient = models.ForeignKey(patient,on_delete=models.CASCADE)
    date = models.DateField()
    time = models.TextField()

    def _str_(self):
         return f"{self.Doctor}-{self.Patient}-{self.date}-{self.time}"
