from django.db import models

# Create your models here.

class Rectangle(models.Model):
    length = models.FloatField()
    width = models.FloatField()

    def calculate_area(self):
        return self.length * self.width