from django.shortcuts import render
from .forms import RectangleForm

def calculate_area(request):
    if request.method == 'POST':
        form = RectangleForm(request.POST)
        if form.is_valid():
            length = form.cleaned_data['length']
            width = form.cleaned_data['width']
            area = length * width
            return render(request, 'area_result.html', {'area': area})
    else:
        form = RectangleForm()
    return render(request, 'calculate_area.html', {'form': form})