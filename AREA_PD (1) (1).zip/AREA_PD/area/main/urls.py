from django.urls import path
from .views import calculate_area

urlpatterns = [
    path('', calculate_area, name='calculate_area'),
]