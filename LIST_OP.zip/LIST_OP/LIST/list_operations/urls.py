from django.urls import path
from .views import list_operations

urlpatterns = [
    path('', list_operations, name='list_operations'),
]
