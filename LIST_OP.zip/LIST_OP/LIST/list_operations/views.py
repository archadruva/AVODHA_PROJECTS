from django.shortcuts import render

# Create your views here.

def list_operations(request):
    numbers = []
    sum_of_elements = 0
    average = 0
    is_empty = True
    duplicates = False

    if request.method == 'POST':
        numbers_str = request.POST.get('numbers', '')
        # Convert input string to a list of integers
        try:
            numbers = [int(num) for num in numbers_str.split(',')]
            is_empty = False if numbers else True

            # Check for duplicates
            if len(numbers) != len(set(numbers)):
                duplicates = True
            
            # Calculate sum and average
            sum_of_elements = sum(numbers)
            average = sum_of_elements / len(numbers)
        except ValueError:
            return render(request, 'list_operations.html', {'error_message': 'Invalid input. Please enter comma-separated integers.'})

    return render(request, 'list_operations.html', {
        'numbers': numbers,
        'sum_of_elements': sum_of_elements,
        'average': average,
        'is_empty': is_empty,
        'duplicates': duplicates
    })

