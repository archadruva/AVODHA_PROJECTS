from django.apps import AppConfig


class ListOperationsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'list_operations'
